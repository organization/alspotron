import { PercentLength } from './addon';
export declare function percent(value: number): PercentLength;
export declare function length(value: number): PercentLength;
