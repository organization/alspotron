import { PercentLength } from './addon';
export * from './util';
declare const idSym: unique symbol;
export declare class Overlay {
    readonly [idSym]: number;
    private constructor();
    /**
     * Update overlay position relative to window
     * @param x x position
     * @param y y position
     */
    setPosition(x: PercentLength, y: PercentLength): Promise<void>;
    /**
     * Update overlay anchor
     * @param x x anchor
     * @param y y anchor
     */
    setAnchor(x: PercentLength, y: PercentLength): Promise<void>;
    /**
     * Update overlay margin
     * @param top top margin
     * @param right right margin
     * @param bottom bottom margin
     * @param left left margin
     */
    setMargin(top: PercentLength, right: PercentLength, bottom: PercentLength, left: PercentLength): Promise<void>;
    /**
     * Update overlay using bitmap buffer. The size of overlay is `width x (data.byteLength / 4 / width)`
     * @param width width of the bitmap
     * @param data bgra formatted bitmap
     */
    updateBitmap(width: number, data: Buffer): Promise<void>;
    /**
     * Destroy overlay
     */
    destroy(): void;
    /**
     * Attach overlay to target process
     * @param dllDir path to dlls
     * @param pid target process pid
     * @param timeout Timeout for injection, in milliseconds. Will wait indefinitely if not provided.
     * @returns new {@link Overlay} object
     */
    static attach(dllDir: string, pid: number, timeout?: number): Promise<Overlay>;
}
/**
 * Default dll directory path
 */
export declare function defaultDllDir(): string;
